#include <math.h>
#define sigema 0.01
#define sita 2

 /* UKF*/
void supdata(float* x_aver,float* p_x,unsigned int n,unsinged int m,float* x)
{
float k=0;
float i=0;
float   lanmude=sigema*sigema*(n+k)-n;

float xi_sigma[2*n]={0};
float x_new[2*n]={0};
float wm[2*n]={0};
float wc[2*n]={0};
xi_sigma[0]=x_aver;
wm[0]=lanmude/(n+lanmude);
wc[0]=(lanmude/(n+lanmude))+(1-sigema*sigema+sita);
for(i=1;i<n;i++)
{
xi_sigma[i]=x_aver+(sqrt((n+lanmude)*p_x));
wm[i]=1/(2*(n+lanmude));
wc[i]=1/(2*(n+lanmude));
}
for(i=n;i<2*n;i++)
{
xi_sigma[i]=x_aver-(sqrt((n+lanmude)*p_x));
wm[i]=1/(2*(n+lanmude));
wc[i]=1/(2*(n+lanmude));
}
x_modelupdat(xi_sigma,x_new);\


}

void sigmagena()
{
}
void ukfupdata()
{

}

 float x_modelupdat(float x_sigame,float x_new)
 {

 }
