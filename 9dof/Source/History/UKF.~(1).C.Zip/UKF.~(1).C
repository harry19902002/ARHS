#include <math.h>


void supdata()
{

}

void sigmagena()
{
}
void ukfupdata()
{

}